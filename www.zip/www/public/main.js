document.querySelector('.wall__item-actions__delete').addEventListener('click', function (e){
   var target = e.currentTarget;

    var elem = document.querySelector('.wall__item wall__item-event');
    target.elem.parentNode.removeChild(elem);
});